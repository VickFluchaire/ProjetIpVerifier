<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <link rel="stylesheet" type="text/css" href="Contacts.css"/>
        <title>Modèle de page pour le TP Contacts</title>
    </head>
    <body>
        <p class="binome">Réalisée par : Costechareyre Benoît et Guezel Clément - Groupe 2J</p> 
        <p class="message">Gestion des contacts</p>
        <p class="erreur"></p>
        
        <table>
            <tr><td>CASTAFIORE</td><td>Bianca</td><td>04 75 58 09 22</td></tr><tr><td>DUPONT</td><td>et DUPOND</td><td>04 90 64 21 77</td></tr><tr><td>HADDOCK</td><td>Capitaine</td><td>04 75 41 04 21</td></tr><tr><td>SANZOT</td><td>Boucherie</td><td>04 75 41 04 31</td></tr><tr><td>TINTIN</td><td>et Milou</td><td>04 75 41 04 22</td></tr><tr><td>TOURNESOL</td><td>Tryfon</td><td>04 75 41 04 23</td></tr>        </table>
    </body>
</html>