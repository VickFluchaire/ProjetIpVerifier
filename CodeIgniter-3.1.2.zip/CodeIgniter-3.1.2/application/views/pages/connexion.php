<?php
session_start();
// Autochargement des classes
function __autoload($class) { require_once "/users/projets/ipverifie/public_html/ProjetIpVerifier/CodeIgniter-3.1.2/bd/Classes/$class.php"; }
$inscrits = new InscritsDAO(MaBD::getInstance());

function toTableRows($inscrits) {
    foreach ($inscrits->getAll() as $c)
        echo "<tr>"
            . "<td>$c->id</td>"
            . "<td>$c->nom</td>"
            . "<td>$c->mail</td>"
            . "<td>$c->validation</td>"
            . "<td>$c->role</td>"
            . "</tr>";
}


if(isset($_POST['connexion'])) {
	if (isset($_POST['login']) && isset($_POST['mdp']))
{
    $_SESSION['login']=$_POST['login'];
    $_SESSION['mdp']=$_POST['mdp'];
    $users = new InscritsDAO(MaBD::getInstance());
	$user = $users->GetOne($_POST['login']);
	$hash = $users->getPassword($_POST['login']);
	
	$options = array('cost' => 11);
	echo $_POST['mdp'];
	if($hash==null){
        header("Location: http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/index.php/connexion");
    }
	if (password_verify($_POST['mdp'], $hash)) {
		$validation=$user->validation;
		$role=$user->role;
		if($role=="admin" && $validation=="OK")
		{
			header("Location: /~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/tab_bord/pages/index2.php");
		}
	}
	else{header("Location: http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/index.php/connexion");}
    /*
    $user = $users->check($_POST['login'],$_POST['mdp']);
    if($user==null){
        
        header("Location: http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/index.php/connexion");
    }
	$validation=$user->validation;
    $role=$user->role;
    if($role=="admin" && $validation=="OK")
    {
        header("Location: /~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/tab_bord/pages/index2.php");
    }
	*/
   
	}
}

if(isset($_POST['inscription']))
{
    $codeValidation=uniqid();
    $hash = password_hash($_POST['mdp_inscription'],PASSWORD_BCRYPT) ;
    $options = array('cost' => 11);

    foreach ($inscrits->getAll() as $user )
    {
        if($user->nom==$_POST['nom_inscription'])
        {
            echo "<script>alert(\"'Veuillez saisir un autre nom d utilisateur'\")</script>";
            unset($_POST);
			header("Location: http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/index.php/connexion");
        }
		
    }
    if (isset($_POST['nom_inscription']) && isset($_POST['mdp_inscription']) && isset($_POST['email_inscription']) &&
            !empty($_POST['nom_inscription']) && !empty($_POST['mdp_inscription']) && !empty($_POST['email_inscription']) && $_POST['mdp_inscription']==$_POST['mdp_confirme_inscription'])
    {
        $nouveau = new Inscrit([ 'id' => $_POST['nom_inscription'], 'nom' => $_POST['nom_inscription'], 'mdp' => $hash,
                         'mail' => $_POST['email_inscription'], 'validation' => $codeValidation , 'role' => "admin" ]);
        mail($_POST['email_inscription'], 'Mail de validation ', "Lien pour confirmer votre inscription: \n\n "
                . "http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/bd/validation.php?codevalidation=$codeValidation");
        $inscrits->insert($nouveau);

        
    }
    
}
if(isset($_POST['back']))
{
	session_destroy();
	header("Location:http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/");
}

?>
<!DOCTYPE html>
<html lang="en">

    <head>

            <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
        <title>Connexion &amp; Inscription</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/css/form-elements.css">
        <link rel="stylesheet" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>
		
        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                	
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            
                        
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-5">
                        	
                        	<div class="form-box">
	                        	<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>Se connecter à IPVERIFIER</h3>
	                            		<p>Remplissez les champs ci-dessous</p>
	                        		</div>
	                        		<div class="form-top-right">
	                        			<i class="fa fa-lock"></i>
	                        		</div>
	                            </div>
	                            <div class="form-bottom">
				                    <form role="form" action="" method="post" class="login-form">
				                    	<div class="form-group">
				                        	<input type="text" name="login" placeholder="Nom d'utilisateur" class="form-username form-control">
				                        </div>
				                        <div class="form-group">
				                        	<input type="password" name="mdp" placeholder="Mot de passe" class="form-password form-control" >
				                        </div>
				                        <button type="submit" name="connexion" class="btn">Se connecter !</button>
				                    </form>
			                    </div>
		                    </div>
		                
		                	<div class="btn">
								<form role="form" action="" method="post" class="login-form">
									<br>
									<button type="submit" name="back" class="btn">Retour à la page d'accueil</button>
								</form>
	                        </div>
	                        
                        </div>
                        
                        <div class="col-sm-1 middle-border"></div>
                        <div class="col-sm-1"></div>
                        	
                        <div class="col-sm-5">
                        	
                        	<div class="form-box">
							
                        		<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>S'inscrire dès maintenant</h3>
	                            		<p>Remplissez les champs ci-dessous</p>
	                        		</div>
	                        		<div class="form-top-right">
	                        			<i class="fa fa-pencil"></i>
	                        		</div>
	                            </div>
	                            <div class="form-bottom">
				                    <form role="form" action="" method="post" class="registration-form" onsubmit="return verifForm(this)">
				                    	<div class="form-group">
				                    		<label class="sr-only" for="form-first-name">nom_inscription</label>
				                        	<input type="text" name="nom_inscription" placeholder="Nom utilisateur" class="form-first-name form-control" onblur="verifNom(this)">
				                        </div>
										<div class="form-group">
				                        	<label class="sr-only" for="form-email">email_inscription</label>
				                        	<input type="text" name="email_inscription" placeholder="Adresse mail" class="form-email form-control" 
											onblur="verifMail(this)">
				                        </div>
										<div class="form-group">
				                    		<label class="sr-only" for="form-first-name">mdp_inscription</label>
				                        	<input type="password" name="mdp_inscription" placeholder="Mot de passe" class="form-first-name form-control" >
				                        </div>
				                        <div class="form-group">
				                        	<label class="sr-only" for="form-last-name">mdp_confirme_inscription</label>
				                        	<input type="password" name="mdp_confirme_inscription" placeholder="Confirmer mot de passe" class="form-last-name form-control" onblur="verifPassword(mdp_inscription,mdp_confirme_inscription)">
				                        </div>
				                        
				                        
				                        <button type="submit" name="inscription" class="btn" >S'inscrire !</button>
				                    </form>
			                    </div>
                        	</div>
                        	
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>

  
	
    </body>
	      <!-- Footer -->
        <footer>
        	<div class="container">
        		<div class="row">
        			
        			
        			
        		</div>
        	</div>
        </footer>

        <!-- Javascript -->
        <script src="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/js/jquery-1.11.1.min.js"></script>
        <script src="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/js/jquery.backstretch.min.js"></script>
        <script src="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/assets/js/scripts.js"></script>
		
        <script src="/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/js/verifInscription.js"></script>
        <!--[if lt IE 10]>
            <script src="CodeIgniter-3.1.2/assets/js/placeholder.js"></script>
        <![endif]-->
	
	

</html>