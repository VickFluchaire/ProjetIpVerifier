<!DOCTYPE html>
<html class="nojs html css_verticalspacer" lang="fr-FR">
 <head>

  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <meta name="generator" content="2017.0.0.363"/>  
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
  <script type="text/javascript"> 
   // Redirect to phone/tablet as necessary
(function(a,b,c){var d=function(){if(navigator.maxTouchPoints>1)return!0;if(window.matchMedia&&window.matchMedia("(-moz-touch-enabled)").matches)return!0;for(var a=["Webkit","Moz","O","ms","Khtml"],b=0,c=a.length;b<c;b++){var f=a[b]+"MaxTouchPoints";if(f in navigator&&navigator[f])return!0}try{return document.createEvent("TouchEvent"),!0}catch(d){}return!1}(),g=function(a){a+="=";for(var b=document.cookie.split(";"),c=0;c<b.length;c++){for(var f=b[c];f.charAt(0)==" ";)f=f.substring(1,f.length);if(f.indexOf(a)==
0)return f.substring(a.length,f.length)}return null};if(g("inbrowserediting")!="true"){var f,g=g("devicelock");g=="phone"&&c?f=c:g=="tablet"&&b&&(f=b);if(g!=a&&!f)if(window.matchMedia)window.matchMedia("(max-device-width: 415px)").matches&&c?f=c:window.matchMedia("(max-device-width: 960px)").matches&&b&&d&&(f=b);else{var a=Math.min(screen.width,screen.height)/(window.devicePixelRatio||1),g=window.screen.systemXDPI||0,i=window.screen.systemYDPI||0,g=g>0&&i>0?Math.min(screen.width/g,screen.height/i):
0;(a<=370||g!=0&&g<=3)&&c?f=c:a<=960&&b&&d&&(f=b)}if(f)document.location=f+(document.location.search||"")+(document.location.hash||""),document.write('<style type="text/css">body {visibility:hidden}</style>')}})("desktop","http://intranet.iut-valence.fr/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/application/views/pages/tablet/index.html","http://intranet.iut-valence.fr/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/application/views/pages/phone/index.html");

// Update the 'nojs'/'js' class on the html node
document.documentElement.className = document.documentElement.className.replace(/\bnojs\b/g, 'js');

// Check that all required assets are uploaded and up-to-date
if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["museutils.js", "museconfig.js", "webpro.js", "musewpslideshow.js", "jquery.museoverlay.js", "touchswipe.js", "jquery.watch.js", "require.js", "index.css"], "outOfDate":[]};
</script>
  
  <link media="only screen and (max-width: 370px)" rel="alternate" href="application/views/pages/phone/index.html"/>
  <link media="only screen and (max-width: 960px)" rel="alternate" href="application/views/pages/tablet/index.html"/>
  <title>Home</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?crc=4056376302"/>
  <link rel="stylesheet" type="text/css" href="css/index.css?crc=4227714569" id="pagesheet"/>
  <!-- IE-only CSS -->
  <!--[if lt IE 9]>
  <link rel="stylesheet" type="text/css" href="css/iefonts_index.css?crc=273913365"/>
  <![endif]-->
  <!-- Other scripts -->
  <script type="text/javascript">
   var __adobewebfontsappname__ = "muse";
</script>
  <!-- JS includes -->
  <script type="text/javascript">
   document.write('\x3Cscript src="' + (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//webfonts.creativecloud.com/montserrat:n4:all;open-sans:n4:all;source-sans-pro:n4,n3,i3,i4,n6:all.js" type="text/javascript">\x3C/script>');
</script>
    <!--custom head HTML-->
  <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
 </head>
 <body>

  <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <a class="anchor_item colelem" id="home"></a>
    <div class="pinned-colelem" id="u4585"><!-- simple frame --></div>
    <a class="nonblock nontext anim_swing clearfix pinned-colelem" id="u2665-4" href="index.html#home"><!-- content --><p>IPVERIFIER</p></a>
    <a class="nonblock nontext anim_swing rounded-corners clearfix pinned-colelem" id="u2668-4" href="index.php/connexion"><!-- content --><p>Inscription - Connexion</p></a>
    <a class="nonblock nontext anim_swing rounded-corners clearfix pinned-colelem" id="u6893-4" href="index.html#services"><!-- content --><p>Présentation</p></a>
    <a class="nonblock nontext anim_swing rounded-corners clearfix pinned-colelem" id="u6896-4" href="index.html#contact"><!-- content --><p>Nous contacter</p></a>
    <div class="clearfix colelem" id="pu2664"><!-- group -->
     <div class="clearfix grpelem" id="u2664"><!-- group -->
      <a class="anchor_item grpelem" id="home2"></a>
      <div class="heading1 clearfix grpelem" id="u2674-4"><!-- content -->
       <p>Services de monitoring de sites et serveurs en ligne</p>
      </div>
     </div>
     <div class="PamphletWidget clearfix widget_invisible grpelem" id="pamphletu2686"><!-- none box -->
      <div class="ThumbGroup clearfix grpelem" id="u2717"><!-- none box -->
       <div class="popup_anchor" id="u2718popup">
        <div class="Thumb popup_element shadow rounded-corners CTA-Button-2 clearfix" id="u2718"><!-- group -->
         <div class="clearfix grpelem" id="u2730-4"><!-- content -->
          <p>En savoir plus</p>
         </div>
        </div>
       </div>
      </div>
      <div class="popup_anchor" id="u2687popup">
       <div class="ContainerGroup rgba-background clearfix" id="u2687"><!-- stack box -->
        <div class="Container rounded-corners clearfix grpelem" id="u2688"><!-- column -->
         <div class="clearfix colelem" id="u2689-4"><!-- content -->
          <p>DROP US A LINE</p>
         </div>
         <form class="form-grp clearfix colelem" id="widgetu2691" method="post" enctype="multipart/form-data" action="scripts/form-u2691.php"><!-- none box -->
          <div class="fld-grp clearfix grpelem" id="widgetu2710" data-required="true"><!-- none box -->
           <label class="fld-label actAsDiv clearfix grpelem" id="u2712-4" for="widgetu2710_input"><!-- content --><span class="actAsPara">Name:</span></label>
           <span class="fld-input NoWrap actAsDiv clearfix grpelem" id="u2711-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu2710_input" name="custom_U2710" tabindex="1"/><label class="wrapped-input fld-prompt" id="widgetu2710_prompt" for="widgetu2710_input"><span class="actAsPara">Enter Name</span></label></span>
          </div>
          <div class="fld-grp clearfix grpelem" id="widgetu2692" data-required="true" data-type="email"><!-- none box -->
           <label class="fld-label actAsDiv clearfix grpelem" id="u2695-4" for="widgetu2692_input"><!-- content --><span class="actAsPara">Email:</span></label>
           <span class="fld-input NoWrap actAsDiv clearfix grpelem" id="u2694-4"><!-- content --><input class="wrapped-input" type="email" spellcheck="false" id="widgetu2692_input" name="Email" tabindex="2"/><label class="wrapped-input fld-prompt" id="widgetu2692_prompt" for="widgetu2692_input"><span class="actAsPara">Enter Email</span></label></span>
          </div>
          <div class="clearfix grpelem" id="u2715-4"><!-- content -->
           <p>Submitting Form...</p>
          </div>
          <div class="clearfix grpelem" id="u2697-4"><!-- content -->
           <p>Your form contains errors. Please try again.</p>
          </div>
          <div class="clearfix grpelem" id="u2716-4"><!-- content -->
           <p>Thank you for your submission!</p>
          </div>
          <button class="submit-btn NoWrap CTA-Button-2 shadow rounded-corners clearfix grpelem" id="u2703-5" type="submit" value="&nbsp;" tabindex="4"><!-- content -->
           <div style="margin-top:-38px;height:38px;">
            <p>&nbsp;</p>
            <p>Submit</p>
           </div>
          </button>
          <div class="fld-grp clearfix grpelem" id="widgetu2698" data-required="false"><!-- none box -->
           <label class="fld-label actAsDiv clearfix grpelem" id="u2700-4" for="widgetu2698_input"><!-- content --><span class="actAsPara">Message:</span></label>
           <span class="fld-textarea actAsDiv clearfix grpelem" id="u2699-4"><!-- content --><textarea class="wrapped-input" id="widgetu2698_input" name="custom_U2698" tabindex="3"></textarea><label class="wrapped-input fld-prompt" id="widgetu2698_prompt" for="widgetu2698_input"><span class="actAsPara">Enter Your Message</span></label></span>
          </div>
         </form>
        </div>
       </div>
      </div>
      <div class="popup_anchor" id="u2723popup">
       <div class="PamphletCloseButton PamphletLightboxPart popup_element CTA-Button-2 shadow clearfix" id="u2723"><!-- group -->
        <div class="clearfix grpelem" id="u2724-4"><!-- content -->
         <p>x</p>
        </div>
       </div>
      </div>
     </div>
     <a class="anchor_item grpelem" id="services"></a>
    </div>
    <div class="clearfix colelem" id="u2766"><!-- column -->
     <div class="heading1 clearfix colelem" id="u2768-4"><!-- content -->
      <p>Présentation de nos services</p>
     </div>
     <div class="clearfix colelem" id="pu2771"><!-- group -->
      <div class="rounded-corners clearfix grpelem" id="u2771"><!-- group -->
       <div class="clip_frame grpelem" id="u2783"><!-- image -->
        <img class="block" id="u2783_img" src="images/branding.png?crc=4293309447" alt="" width="123" height="65"/>
       </div>
      </div>
      <div class="rounded-corners clearfix grpelem" id="u2772"><!-- group -->
       <div class="clip_frame grpelem" id="u2785"><!-- image -->
        <img class="block" id="u2785_img" src="images/design.png?crc=4137836799" alt="" width="48" height="142"/>
       </div>
      </div>
      <div class="rounded-corners clearfix grpelem" id="u2773"><!-- group -->
       <div class="clip_frame grpelem" id="u2787"><!-- image -->
        <img class="block" id="u2787_img" src="images/development.png?crc=3825955620" alt="" width="111" height="111"/>
       </div>
      </div>
     </div>
     <div class="clearfix colelem" id="pu2775-4"><!-- group -->
      <div class="heading2 clearfix grpelem" id="u2775-4"><!-- content -->
       <h2>Analysez l'intégrité de vos sites</h2>
      </div>
      <div class="heading2 clearfix grpelem" id="u4569-4"><!-- content -->
       <h2>Une interface simple et ergonomique</h2>
      </div>
      <div class="heading2 clearfix grpelem" id="u4571-4"><!-- content -->
       <h2>Des offres adaptées à vos besoins</h2>
      </div>
     </div>
     <div class="clearfix colelem" id="pu2774"><!-- group -->
      <div class="rounded-corners clearfix grpelem" id="u2774"><!-- group -->
       <div class="clip_frame grpelem" id="u2789"><!-- image -->
        <img class="block" id="u2789_img" src="images/responsive.png?crc=3841902940" alt="" width="89" height="122"/>
       </div>
      </div>
      <div class="rounded-corners clearfix grpelem" id="u2791"><!-- group -->
       <div class="clip_frame grpelem" id="u2797"><!-- image -->
        <img class="block" id="u2797_img" src="images/marketing.png?crc=394608204" alt="" width="113" height="77"/>
       </div>
      </div>
      <div class="rounded-corners clearfix grpelem" id="u2794"><!-- group -->
       <div class="clip_frame grpelem" id="u2799"><!-- image -->
        <img class="block" id="u2799_img" src="images/seo.png?crc=392808605" alt="" width="117" height="101"/>
       </div>
      </div>
     </div>
     <div class="clearfix colelem" id="pu4579-4"><!-- group -->
      <div class="heading2 clearfix grpelem" id="u4579-4"><!-- content -->
       <h2>Emmenez IPVERIFIER partout avec vous</h2>
      </div>
      <div class="heading2 clearfix grpelem" id="u4582-4"><!-- content -->
       <h2>Notifications par email</h2>
      </div>
      <div class="heading2 clearfix grpelem" id="u4583-4"><!-- content -->
       <h2>Notifications par SMS</h2>
      </div>
     </div>
     <a class="anchor_item colelem" id="contact"></a>
    </div>
    <div class="clearfix colelem" id="pu3159-3"><!-- group -->
     <div class="clearfix grpelem" id="u3159-3"><!-- content -->
      <p>&nbsp;</p>
     </div>
     <div class="heading1 clearfix grpelem" id="u3175-4"><!-- content -->
      <p>Nous contacter</p>
     </div>
     <form class="form-grp clearfix grpelem" id="widgetu3177" method="post" enctype="multipart/form-data" action="scripts/form-u3177.php"><!-- none box -->
      <div class="fld-grp clearfix grpelem" id="widgetu3193" data-required="true"><!-- none box -->
       <span class="fld-input NoWrap actAsDiv rounded-corners Form shadow clearfix grpelem" id="u3196-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu3193_input" name="custom_U3193" tabindex="5"/><label class="wrapped-input fld-prompt" id="widgetu3193_prompt" for="widgetu3193_input"><span class="actAsPara">Nom</span></label></span>
      </div>
      <div class="fld-grp clearfix grpelem" id="widgetu3178" data-required="true" data-type="email"><!-- none box -->
       <span class="fld-input NoWrap actAsDiv Form rounded-corners shadow clearfix grpelem" id="u3181-4"><!-- content --><input class="wrapped-input" type="email" spellcheck="false" id="widgetu3178_input" name="Email" tabindex="6"/><label class="wrapped-input fld-prompt" id="widgetu3178_prompt" for="widgetu3178_input"><span class="actAsPara">Adresse mail</span></label></span>
      </div>
      <div class="clearfix grpelem" id="u3191-4"><!-- content -->
       <p>Submitting Form...</p>
      </div>
      <div class="clearfix grpelem" id="u3192-4"><!-- content -->
       <p>There was an error with your submission. Please try again.</p>
      </div>
      <div class="clearfix grpelem" id="u3198-4"><!-- content -->
       <p>Thank you for submitting your query. One of our representatives will be in touch with you shortly.</p>
      </div>
      <button class="submit-btn NoWrap shadow rounded-corners CTA-Button clearfix grpelem" id="u3199-4" type="submit" value="Envoyer !" tabindex="8"><!-- content -->
       <div style="margin-top:-21px;height:21px;">
        <p>Envoyer !</p>
       </div>
      </button>
      <div class="fld-grp clearfix grpelem" id="widgetu3200" data-required="false"><!-- none box -->
       <span class="fld-textarea actAsDiv Form rounded-corners shadow clearfix grpelem" id="u3202-4"><!-- content --><textarea class="wrapped-input" id="widgetu3200_input" name="custom_U3200" tabindex="7"></textarea><label class="wrapped-input fld-prompt" id="widgetu3200_prompt" for="widgetu3200_input"><span class="actAsPara">Ecrivez un message...</span></label></span>
      </div>
     </form>
     <div class="clearfix grpelem" id="u3205-4"><!-- content -->
      <p>25 Rue Frédéric Chopin, 26000 Valence, France</p>
     </div>
     <div class="size_fixed grpelem" id="u6915"><!-- custom html -->
      
<iframe class="actAsDiv" style="width:100%;height:100%;" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;q=25%2C%20Rue%20Fr%C3%A9d%C3%A9ric%20Chopin&amp;aq=0&amp;ie=UTF8&amp;t=p&amp;z=12&amp;iwloc=A&amp;output=embed"></iframe>

     </div>
    </div>
    <div class="clearfix colelem" id="pu3160"><!-- group -->
     <div class="clearfix grpelem" id="u3160"><!-- group -->
      <div class="size_fixed grpelem" id="u3207"><!-- custom html -->
       
<a href="http://www.adobe.com/products/muse.html"><img class="actAsDiv" width="129" src="http://musebadge.com/assets/madewithmuse-en_US.png" alt="Made with Adobe Muse"/></a>

      </div>
     </div>
     <div class="grpelem" id="u3161"><!-- state-based BG images --></div>
     <div class="grpelem" id="u3163"><!-- state-based BG images --></div>
     <div class="grpelem" id="u3165"><!-- state-based BG images --></div>
     <div class="grpelem" id="u3167"><!-- state-based BG images --></div>
     <div class="grpelem" id="u3169"><!-- state-based BG images --></div>
     <div class="grpelem" id="u3171"><!-- state-based BG images --></div>
     <div class="grpelem" id="u3173"><!-- state-based BG images --></div>
    </div>
    <div class="verticalspacer" data-offset-top="2682" data-content-above-spacer="2681" data-content-below-spacer="0"></div>
   </div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u3161-r.png?crc=278598571" alt=""/>
   <img class="preload" src="images/u3163-r.png?crc=427453210" alt=""/>
   <img class="preload" src="images/u3165-r.png?crc=321456869" alt=""/>
   <img class="preload" src="images/u3167-r.png?crc=338771346" alt=""/>
   <img class="preload" src="images/u3169-r.png?crc=3821930293" alt=""/>
   <img class="preload" src="images/u3171-r.png?crc=59429556" alt=""/>
   <img class="preload" src="images/u3173-r.png?crc=146870850" alt=""/>
  </div>
  <!-- Other scripts -->
  <script type="text/javascript">
   window.Muse.assets.check=function(d){if(!window.Muse.assets.checked){window.Muse.assets.checked=!0;var b={},c=function(a,b){if(window.getComputedStyle){var c=window.getComputedStyle(a,null);return c&&c.getPropertyValue(b)||c&&c[b]||""}if(document.documentElement.currentStyle)return(c=a.currentStyle)&&c[b]||a.style&&a.style[b]||"";return""},a=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),
16);return 0},g=function(g){for(var f=document.getElementsByTagName("link"),h=0;h<f.length;h++)if("text/css"==f[h].type){var i=(f[h].href||"").match(/\/?css\/([\w\-]+\.css)\?crc=(\d+)/);if(!i||!i[1]||!i[2])break;b[i[1]]=i[2]}f=document.createElement("div");f.className="version";f.style.cssText="display:none; width:1px; height:1px;";document.getElementsByTagName("body")[0].appendChild(f);for(h=0;h<Muse.assets.required.length;){var i=Muse.assets.required[h],l=i.match(/([\w\-\.]+)\.(\w+)$/),k=l&&l[1]?
l[1]:null,l=l&&l[2]?l[2]:null;switch(l.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");f.className+=" "+k;k=a(c(f,"color"));l=a(c(f,"backgroundColor"));k!=0||l!=0?(Muse.assets.required.splice(h,1),"undefined"!=typeof b[i]&&(k!=b[i]>>>24||l!=(b[i]&16777215))&&Muse.assets.outOfDate.push(i)):h++;f.className="version";break;case "js":h++;break;default:throw Error("Unsupported file type: "+l);}}d?d().jquery!="1.8.3"&&Muse.assets.outOfDate.push("jquery-1.8.3.min.js"):Muse.assets.required.push("jquery-1.8.3.min.js");
f.parentNode.removeChild(f);if(Muse.assets.outOfDate.length||Muse.assets.required.length)f="Certains fichiers sur le serveur sont peut-être manquants ou incorrects. Videz le cache du navigateur et réessayez. Si le problème persiste, contactez le créateur du site.",g&&Muse.assets.outOfDate.length&&(f+="\nOut of date: "+Muse.assets.outOfDate.join(",")),g&&Muse.assets.required.length&&(f+="\nMissing: "+Muse.assets.required.join(",")),alert(f)};location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi)?setTimeout(function(){g(!0)},5E3):g()}};
var muse_init=function(){require.config({baseUrl:""});require(["jquery","museutils","whatinput","webpro","musewpslideshow","jquery.museoverlay","touchswipe","jquery.watch"],function(d){var $ = d;$(document).ready(function(){try{
window.Muse.assets.check($);/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.initWidget('#widgetu2691', ['#bp_infinity'], function(elem) { return new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu2691 */
Muse.Utils.initWidget('#pamphletu2686', ['#bp_infinity'], function(elem) { return new WebPro.Widget.ContentSlideShow(elem, {contentLayout_runtime:'lightbox',event:'click',deactivationEvent:'none',autoPlay:false,displayInterval:3000,transitionStyle:'horizontal',transitionDuration:500,hideAllContentsFirst:false,shuffle:false,enableSwipe:true,resumeAutoplay:false,resumeAutoplayInterval:3000,playOnce:false,autoActivate_runtime:false}); });/* #pamphletu2686 */
Muse.Utils.initWidget('#widgetu3177', ['#bp_infinity'], function(elem) { return new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu3177 */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
}catch(b){if(b&&"function"==typeof b.notify?b.notify():Muse.Assert.fail("Error calling selector function: "+b),false)throw b;}})})};

</script>
  <!-- RequireJS script -->
  <script src="scripts/require.js?crc=244322403" type="text/javascript" async data-main="scripts/museconfig.js?crc=168988563" onload="if (requirejs) requirejs.onError = function(requireType, requireModule) { if (requireType && requireType.toString && requireType.toString().indexOf && 0 <= requireType.toString().indexOf('#scripterror')) window.Muse.assets.check(); }" onerror="window.Muse.assets.check();"></script>
   </body>
</html>













