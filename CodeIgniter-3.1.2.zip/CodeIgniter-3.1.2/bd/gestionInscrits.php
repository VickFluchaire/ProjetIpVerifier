<?php
session_start();
// Autochargement des classes
function __autoload($class) { require_once "Classes/$class.php"; }
$inscrits = new InscritsDAO(MaBD::getInstance());

if (isset($_SESSION['login']) && isset($_SESSION['mdp']))
{
    $users = new InscritsDAO(MaBD::getInstance());
    $user = $users->check($_SESSION['login'],$_SESSION['mdp']);
    $name=$user->prenom.' '.$user->nom;
    if($user==null){
        header("Location: connexion.php");
    }
    if($inscrits->getOne($_SESSION['login'])->role!="Administrateur")
    {
        //header("Location: connexion.php");
    }
}
if(isset($_POST['deco']))
{
    session_destroy(); //unset($_SESSION['login'],$_SESSION['mdp']);
    header("Location: connexion.php");
}
if(isset($_POST['delete']))
{
    $valid = new InscritsDAO(MaBD::getInstance());
    $valid->deleteUser($_POST['id']);
}
if(isset($_POST['upgrade']))
{
    $valid = new InscritsDAO(MaBD::getInstance());
    $valid->updateUser($_POST['id']);
}
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css" />
        <title>TP Newsletter</title>
    </head>
    <body>
        <pre><?php print_r($_SESSION) ?></pre>
        <h1>Gestion des inscrits</h1>
        <p><?php echo 'Bonjour '.$name ?>
            <form method="post">
                <input type="hidden" name="deco"/>
                <input type="button" value="Deconnexion" onClick="submit()"/>
            </form>
        </p>
        <p>Réalisés par le binôme Guezel-Clément &amp; Costechareyre-Benoît</p>
        <form method="post">
                <input type="text" name="id" placeholder="id de la personne à supprimer" /><br>
                <input type="hidden" name="delete"/>
                <input type="button" value="Supprimer" onClick="submit()"/>
        </form>
        <form method="post">
                <input type="text" name="id" placeholder="id New Redacteur" /><br>
                <input type="hidden" name="upgrade"/>
                <input type="button" value="Passer en redacteur" onClick="submit()"/>
        </form>
    </body> 
</html>
<STYLE>
    table tr:nth-child(odd)
{
    background-color:#CCCCFF;
}
</STYLE>