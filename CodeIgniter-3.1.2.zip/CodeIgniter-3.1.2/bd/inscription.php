<?php
session_start();
// Autochargement des classes
function __autoload($class) { require_once "Classes/$class.php"; }

$inscrits = new InscritsDAO(MaBD::getInstance());
function toTableRows($inscrits) {
    foreach ($inscrits->getAll() as $c)
        echo "<tr>"
            . "<td>$c->id</td>"
            . "<td>$c->nom</td>"
            . "<td>$c->prenom</td>"
            . "<td>$c->mail</td>"
            . "<td>$c->validation</td>"
            . "<td>$c->role</td>"
            . "</tr>";
}
$codeValidation=uniqid();

if(isset($_POST['valid']))
{
    foreach ($inscrits->getAll() as $user )
    {
        if($user->nom==$_POST['nom'])
        {
            echo 'Veuillez saisir un autre nom d utilisateur';
            unset($_POST);
        }
    }
    if (isset($_POST['nom']) && isset($_POST['mdp']) && isset($_POST['mail']) &&
            !empty($_POST['nom']) && !empty($_POST['mdp']) && !empty($_POST['mail']))
    {
        $nouveau = new Inscrit([ 'id' => $_POST['nom'], 'nom' => $_POST['nom'], 'prenom' => $_POST['prénom'], 'mdp' => $_POST['mdp'],
                         'mail' => $_POST['mail'], 'validation' => $codeValidation , 'role' => "Utilisateur" ]);
        mail($_POST['mail'], 'Mail de validation ', "Lien pour confirmer votre adhésion à notre superbe revue: \n\n "
                . "http://gigondas/~costechb/mesTPs/S3/Prog_web/TP-Newsletter/validation.php?codevalidation=$codeValidation");
        $inscrits->insert($nouveau);

        //print_r($_POST);
        header("Location: connexion.php");   
    }
    else 
    {
        echo 'Veuillez saisir un nom, un mot de passe et un mail';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css" />
        <title>TP Newsletter</title>
    </head>
    <body>
        <pre><?php print_r($_SESSION) ?></pre>
        <h1>Inscription</h1>
        <p>Réalisés par le binôme Guezel-Clément &amp; Costechareyre-Benoît</p>
        <form method="post">
            <p class="form">
                <input type="text" name="nom" placeholder="nom(*)" /><br>
                <input type="text" name="prénom" placeholder="prénom" /><br>
                <input type="text" name="mail" placeholder="mail(*)" /><br>
                <input type="password" name="mdp" placeholder="mot de passe(*)"/><br>
                
                <input type="hidden" name="valid"/>
                <input type="button" value="Valider" onclick="submit()" />
            </p>
        </form> 
    </body> 
</html>
<STYLE>
    table tr:nth-child(odd)
    {
        background-color:#CCADFF;
    }
</STYLE>