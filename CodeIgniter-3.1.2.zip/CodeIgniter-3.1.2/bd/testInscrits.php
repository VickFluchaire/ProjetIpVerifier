<?php
// Autochargement des classes
function __autoload($class) { require_once "Classes/$class.php"; }

function afficheTout($inscrits) {
    echo "------- Tous les inscrits :\n";
    foreach ($inscrits->getAll() as $c)
        echo $c, "\n";
    echo "---------------------------\n";
}

$moi = new Inscrit([ 'id' => "genthial", 'nom' => "GENTHIAL", 'prenom' => "Damien", 'mdp' => "genthial",
                     'mail' => "Damien.Genthial@iut-valence.fr", 'validation' => "**", 'role' => "Utilisateur" ]);
echo $moi, "\n";
$inscrits = new InscritsDAO(MaBD::getInstance());
echo $inscrits->getOne("1"), "\n";
echo $inscrits->getOne("2"), "\n";

afficheTout($inscrits);

echo "Enregistrement de ";
$inscrits->insert($moi);
echo $moi, "\n";

afficheTout($inscrits);

echo "Modification de $moi\n";
$moi->validation = uniqid();
$inscrits->update($moi);
echo "\t==> $moi\n";

afficheTout($inscrits);

echo "Effacement de $moi\n";
$inscrits->delete($moi);

afficheTout($inscrits);

?>
