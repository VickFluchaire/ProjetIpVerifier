<?php
session_start();
// Autochargement des classes
function __autoload($class) { require_once "Classes/$class.php"; }
$inscrits = new InscritsDAO(MaBD::getInstance());
function toTableRows($inscrits) {
    foreach ($inscrits->getAll() as $c)
        echo "<tr>"
            . "<td>$c->id</td>"
            . "<td>$c->nom</td>"
            . "<td>$c->prenom</td>"
            . "<td>$c->mail</td>"
            . "<td>$c->validation</td>"
            . "<td>$c->role</td>"
            . "</tr>";
}
$user = $inscrits->check($_SESSION['login'],$_SESSION['mdp']);
if($user==null){
    header("Location: connexion.php");
}
$name=$user->prenom.' '.$user->nom;
if(isset($_POST['deco']))
{
    session_destroy(); //unset($_SESSION['login'],$_SESSION['mdp']);
    header("Location: connexion.php");
}
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css" />
        <title>TP Newsletter</title>
    </head>
    <body>
        <pre><?php print_r($_SESSION) ?></pre>
        <h1>Liste des inscrits</h1>
        <p><?php echo 'Bonjour '.$name ?>
            <form method="post">
                <input type="hidden" name="deco"/>
                <input type="button" value="Deconnexion" onClick="submit()"/>
            </form>
        </p>
        <p>Réalisés par le binôme Guezel-Clément &amp; Costechareyre-Benoît</p>
        <table
            <th><td>Id</td><td>Nom</td><td>Prenom</td><td>E-mail</td><td>Validation</td><td>Rôle</td></th>
            <?php toTableRows($inscrits); ?>
        </table>
    </body> 
</html>
<STYLE>
    table tr:nth-child(odd)
{
    background-color:#CCCCFF;
}
</STYLE>