<?php
session_start();
// Autochargement des classes
function __autoload($class) { require_once "/users/projets/ipverifie/public_html/ProjetIpVerifier/CodeIgniter-3.1.2/bd/Classes/$class.php"; }

    $usersB = new InscritsDAO(MaBD::getInstance());
    $userB = $usersB->checkValidationBis($_GET['codevalidation']);
    if($userB==null)
        header("Location:  http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/index.php/connexion");
    else 
    {
        $valid = new InscritsDAO(MaBD::getInstance());
        $valid->updateValidation($_GET["codevalidation"]);
		//echo 'bonjour'.$_GET["codevalidation"];
        //header("Location: http://gigondas/~ipverifie/ProjetIpVerifier/CodeIgniter-3.1.2/index.php/connexion");
    }  

?>
