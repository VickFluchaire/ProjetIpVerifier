<?php
class Inscrit extends TableObject {
    static public $tableName = "Inscrits";
    static public $keyFieldsNames = array('id');
    public $hasAutoIncrementedKey = false;
}

?>
