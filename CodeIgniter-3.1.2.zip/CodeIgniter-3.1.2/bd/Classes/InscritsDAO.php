<?php

class InscritsDAO extends DAO {
    protected $class = "Inscrit";
    
    /*public function check($login,$mdp){
        $stmt = $this->pdo->prepare("SELECT * FROM Inscrits WHERE nom='$login' AND mdp='$mdp'");
        $stmt->execute(array($login,$mdp));
        $res=$stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($res)==0)
            return null;
        else 
            return new Inscrit($res[0]);
            
    }**/
	
	public function getPassword($login){
        $stmt = $this->pdo->prepare("SELECT * FROM Inscrits WHERE nom='$login' ");
		$stmt->execute();
		$res=$stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($res)==0)
            return null;
        else 
            return $res[0]['mdp'];
	}
	public function getIdUser($login){
        $stmt = $this->pdo->prepare("SELECT * FROM Inscrits WHERE nom='$login' ");
		$stmt->execute();
		$res=$stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($res)==0)
            return null;
        else 
            return $res[0]['id'];
	}
	
	public function GetOne($login){
        $stmt = $this->pdo->prepare("SELECT * FROM Inscrits WHERE nom='$login'");
        $stmt->execute();
        $res=$stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($res)==0)
            return null;
        else 
            return new Inscrit($res[0]);
            
    }
	
    public function checkValidationBis($codeValidation){
        $stmt = $this->pdo->prepare("SELECT * FROM Inscrits WHERE validation='$codeValidation'");
        $stmt->execute(array($codeValidation));
        $res=$stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($res)==0)
            return null;
        else 
            return new Inscrit($res[0]);
            
    }
    
    public function updateValidation($codeValidation){
		$stmt = $this->pdo->prepare("UPDATE Inscrits SET validation = 'OK' WHERE validation='$codeValidation'");
        $stmt->execute(array($codeValidation));
    }
    public function deleteUser($id){
        $this->pdo->prepare("DELETE FROM Inscrits WHERE id='$id' ");
        $stmt->execute(array($id));
    }
    public function updateUser($id){
        $this->pdo->prepare("UPDATE Inscrits SET role = 'Admin' WHERE id='$id' ");
        $stmt->execute(array($id));
    }
	
	// fonction pour récupérer les sites d'un utilisateur

	public function GetSiteUser($id){
        $stmt = $this->pdo->prepare("SELECT nom,adresseIp FROM Sites WHERE id_utilisateur=:id");
        $stmt->execute(array(':id'=>$id));
        $res=$stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($res)==0)
            return null;
        else 
            return $res;
            
    }
	
	// fonctions de modification du profil
	
	public function updateMDP($login,$mdp){
		$stmt = $this->pdo->prepare("UPDATE Inscrits SET mdp =:mdp WHERE nom=:login ");
        $stmt->execute(array(":mdp"=>$mdp,":login"=>$login));
    }
	public function updateMail($login,$mail){
		$stmt = $this->pdo->prepare("UPDATE Inscrits SET mail =:mail WHERE nom=:login ");
        $stmt->execute(array(":mail"=>$mail,":login"=>$login));
    }
	
	public function updateTel($login,$telephone){
		$stmt = $this->pdo->prepare("UPDATE Inscrits SET telephone =:telephone WHERE nom=:login ");
        $stmt->execute(array(":telephone"=>$telephone,":login"=>$login));
    }
	// fonctions d'ajout de site
	
	public function addWebSite($name,$id_user,$ip_site){
		$stmt = $this->pdo->prepare("INSERT INTO Sites (nom,adresseIp,id_utilisateur) VALUES (?,?,?) ");
        $stmt->execute(array($name,$ip_site,$id_user));
    }
}
?>