<?php
session_start();
// Autochargement des classes
function __autoload($class) { require_once "Classes/$class.php"; }
$inscrits = new InscritsDAO(MaBD::getInstance());
function toTableRows($inscrits) {
    foreach ($inscrits->getAll() as $c)
        echo "<tr>"
            . "<td>$c->id</td>"
            . "<td>$c->nom</td>"
            . "<td>$c->prenom</td>"
            . "<td>$c->mail</td>"
            . "<td>$c->validation</td>"
            . "<td>$c->role</td>"
            . "</tr>";
}
if (isset($_POST['login']) && isset($_POST['mdp']))
{
    $_SESSION['login']=$_POST['login'];
    $_SESSION['mdp']=$_POST['mdp'];
    $users = new InscritsDAO(MaBD::getInstance());
    $user = $users->check($_POST['login'],$_POST['mdp']);
    if($user==null){
        echo 'Login ou mot de passe incorrect';
        header("Location: connexion.php");
    }
    $role=$user->role;
    if($role=="Administrateur")
    {
        header("Location: gestionInscrits.php");
    }
    if($role=="Redacteur")
    {
        header("Location: envoi.php");
    }
    if($role=="Utilisateur")
    {
        header("Location: listeInscrits.php");
    }
}
if(isset($_POST['Inscription']))
{
    header("Location: inscription.php");
}
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css" />
        <title>TP Newsletter</title>
    </head>
    <body>
        <pre><?php print_r($_SESSION) ?></pre>
        <h1>Connexion</h1>
        <p>Réalisés par le binôme Guezel-Clément &amp; Costechareyre-Benoît</p>
        <form method="post">
            <p class="form">
                <input type="text" name="login" placeholder="nom" /><br>
                <input type="password" name="mdp" placeholder="mdp"/><br>
                <input type="button" value="Connexion" onclick="submit()" />
            </p>
        </form>
        <form method="post">
            <input type="hidden" name="Inscription"/>
            <input type="button" value="Inscription" onclick="submit()" />
        </form>
    </body> 
</html>
<STYLE>
    table tr:nth-child(odd)
    {
        background-color:#CCADFF;
    }
</STYLE>